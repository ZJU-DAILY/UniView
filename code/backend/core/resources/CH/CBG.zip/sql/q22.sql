SELECT demo_alias.d_a_cnt AS __fcol_15, demo_alias.pt_d AS __fcol_45 FROM cbg.demo AS demo_alias LIMIT 10
