SELECT toDate(demo_alias.pt_d) AS __fcol_49 FROM cbg.demo AS demo_alias GROUP BY toDate(demo_alias.pt_d)
