CREATE MATERIALIZED VIEW IF NOT EXISTS mv76 AS
SELECT
	item.i_brand,
	item.i_units,
	item.i_size,
	warehouse.w_county,
	warehouse.w_warehouse_sk,
	inventory.inv_date_sk,
	inventory.inv_quantity_on_hand,
	item.i_product_name,
	inventory.inv_item_sk,
	item.i_item_desc,
	item.i_manufact_id,
	warehouse.w_country,
	item.i_item_sk,
	item.i_brand_id,
	warehouse.w_city,
	warehouse.w_state,
	item.i_item_id,
	inventory.inv_warehouse_sk,
	item.i_category_id,
	item.i_color,
	warehouse.w_warehouse_name,
	item.i_wholesale_cost,
	warehouse.w_warehouse_sq_ft,
	item.i_class_id,
	item.i_category,
	item.i_manufact,
	item.i_class,
	item.i_current_price,
	item.i_manager_id
FROM
	item,
	warehouse,
	inventory
WHERE
	inventory.inv_warehouse_sk = warehouse.w_warehouse_sk
	AND inventory.inv_item_sk = item.i_item_sk