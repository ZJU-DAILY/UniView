SELECT
	date_dim.d_month_seq,
	date_dim.d_dom,
	catalog_returns.cr_returned_date_sk,
	catalog_returns.cr_item_sk,
	catalog_returns.cr_reversed_charge,
	date_dim.d_day_name,
	date_dim.d_dow,
	catalog_returns.cr_call_center_sk,
	date_dim.d_year,
	call_center.cc_name,
	catalog_returns.cr_catalog_page_sk,
	catalog_returns.cr_return_amt_inc_tax,
	date_dim.d_moy,
	catalog_returns.cr_store_credit,
	call_center.cc_call_center_sk,
	call_center.cc_county,
	catalog_returns.cr_returning_addr_sk,
	call_center.cc_call_center_id,
	catalog_returns.cr_returning_customer_sk,
	date_dim.d_quarter_name,
	date_dim.d_qoy,
	catalog_returns.cr_net_loss,
	date_dim.d_week_seq,
	catalog_returns.cr_order_number,
	catalog_returns.cr_return_quantity,
	call_center.cc_manager,
	date_dim.d_date_sk,
	date_dim.d_date,
	catalog_returns.cr_refunded_cash,
	catalog_returns.cr_return_amount
FROM
	catalog_returns,
	date_dim,
	call_center
WHERE
	call_center.cc_call_center_sk = catalog_returns.cr_call_center_sk
	AND catalog_returns.cr_returned_date_sk = date_dim.d_date_sk
	AND date_dim.d_moy = 11
	AND date_dim.d_year = 1998