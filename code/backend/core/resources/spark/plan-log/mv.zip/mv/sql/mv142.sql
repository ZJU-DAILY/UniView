SELECT
	item.i_brand,
	date_dim.d_month_seq,
	item.i_units,
	item.i_size,
	date_dim.d_dom,
	inventory.inv_date_sk,
	inventory.inv_quantity_on_hand,
	date_dim.d_day_name,
	item.i_product_name,
	inventory.inv_item_sk,
	item.i_item_desc,
	date_dim.d_dow,
	item.i_manufact_id,
	date_dim.d_year,
	item.i_item_sk,
	item.i_brand_id,
	item.i_item_id,
	date_dim.d_date,
	item.i_category_id,
	inventory.inv_warehouse_sk,
	item.i_color,
	date_dim.d_moy,
	item.i_wholesale_cost,
	date_dim.d_quarter_name,
	date_dim.d_qoy,
	item.i_class_id,
	date_dim.d_week_seq,
	item.i_category,
	item.i_manufact,
	item.i_class,
	date_dim.d_date_sk,
	item.i_current_price,
	item.i_manager_id
FROM
	item,
	inventory,
	date_dim
WHERE
	(((item.i_manufact_id = 677) OR (item.i_manufact_id = 940) OR (item.i_manufact_id = 694) OR (item.i_manufact_id = 808)) OR ((item.i_manufact_id = 129) OR (item.i_manufact_id = 270) OR (item.i_manufact_id = 821) OR (item.i_manufact_id = 423)))
	AND item.i_item_sk = inventory.inv_item_sk
	AND (((inventory.inv_quantity_on_hand >= 100) AND (inventory.inv_quantity_on_hand <= 500)))
	AND inventory.inv_date_sk = date_dim.d_date_sk