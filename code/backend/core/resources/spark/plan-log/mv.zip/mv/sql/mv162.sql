SELECT
	store.s_company_name,
	store.s_store_id,
	date_dim.d_month_seq,
	date_dim.d_dom,
	household_demographics.hd_income_band_sk,
	store.s_gmt_offset,
	store_sales.ss_net_paid,
	date_dim.d_year,
	store_sales.ss_ticket_number,
	store.s_number_employees,
	date_dim.d_moy,
	store_sales.ss_addr_sk,
	store_sales.ss_promo_sk,
	store_sales.ss_customer_sk,
	store_sales.ss_ext_tax,
	date_dim.d_quarter_name,
	store_sales.ss_coupon_amt,
	household_demographics.hd_dep_count,
	store_sales.ss_hdemo_sk,
	store.s_state,
	date_dim.d_qoy,
	store.s_store_sk,
	store_sales.ss_quantity,
	store.s_street_type,
	store.s_zip,
	store_sales.ss_sold_time_sk,
	store.s_city,
	store_sales.ss_sales_price,
	store_sales.ss_ext_discount_amt,
	store.s_company_id,
	store_sales.ss_store_sk,
	household_demographics.hd_buy_potential,
	date_dim.d_day_name,
	store.s_street_name,
	store_sales.ss_ext_list_price,
	date_dim.d_dow,
	store_sales.ss_sold_date_sk,
	store.s_street_number,
	store.s_market_id,
	store_sales.ss_ext_sales_price,
	store_sales.ss_cdemo_sk,
	household_demographics.hd_demo_sk,
	store_sales.ss_net_profit,
	store_sales.ss_ext_wholesale_cost,
	store_sales.ss_list_price,
	store.s_store_name,
	store.s_suite_number,
	store_sales.ss_wholesale_cost,
	household_demographics.hd_vehicle_count,
	date_dim.d_week_seq,
	store.s_county,
	date_dim.d_date_sk,
	date_dim.d_date,
	store_sales.ss_item_sk
FROM
	store_sales,
	store,
	date_dim,
	household_demographics
WHERE
	(((store.s_city = 'Fairview') OR (store.s_city = 'Midway')))
	AND store_sales.ss_store_sk = store.s_store_sk
	AND store_sales.ss_hdemo_sk = household_demographics.hd_demo_sk
	AND store_sales.ss_sold_date_sk = date_dim.d_date_sk
	AND household_demographics.hd_dep_count = 4
	AND household_demographics.hd_vehicle_count = 3
	AND (((date_dim.d_dow = 6) OR (date_dim.d_dow = 0)))
	AND (((date_dim.d_year = 1999) OR (date_dim.d_year = 2000) OR (date_dim.d_year = 2001)))