SELECT
	inventory.inv_warehouse_sk,
	warehouse.w_warehouse_name,
	warehouse.w_county,
	warehouse.w_warehouse_sk,
	inventory.inv_date_sk,
	inventory.inv_quantity_on_hand,
	warehouse.w_warehouse_sq_ft,
	inventory.inv_item_sk,
	warehouse.w_country,
	warehouse.w_city,
	warehouse.w_state
FROM
	warehouse,
	inventory
WHERE
	inventory.inv_warehouse_sk = warehouse.w_warehouse_sk