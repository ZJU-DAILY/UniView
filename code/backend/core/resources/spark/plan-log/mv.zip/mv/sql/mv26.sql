SELECT
	date_dim.d_month_seq,
	customer_demographics.cd_education_status,
	date_dim.d_dom,
	customer_demographics.cd_demo_sk,
	store_sales.ss_net_paid,
	date_dim.d_year,
	store_sales.ss_ticket_number,
	date_dim.d_moy,
	store_sales.ss_addr_sk,
	store_sales.ss_promo_sk,
	store_sales.ss_customer_sk,
	store_sales.ss_ext_tax,
	customer_demographics.cd_dep_employed_count,
	store_sales.ss_coupon_amt,
	date_dim.d_qoy,
	date_dim.d_quarter_name,
	store_sales.ss_hdemo_sk,
	customer_demographics.cd_credit_rating,
	store_sales.ss_quantity,
	customer_demographics.cd_dep_count,
	store_sales.ss_sold_time_sk,
	store_sales.ss_sales_price,
	store_sales.ss_ext_discount_amt,
	store_sales.ss_store_sk,
	date_dim.d_day_name,
	store_sales.ss_ext_list_price,
	store_sales.ss_sold_date_sk,
	date_dim.d_dow,
	customer_demographics.cd_marital_status,
	store_sales.ss_ext_sales_price,
	store_sales.ss_cdemo_sk,
	store_sales.ss_list_price,
	store_sales.ss_ext_wholesale_cost,
	customer_demographics.cd_dep_college_count,
	store_sales.ss_net_profit,
	customer_demographics.cd_purchase_estimate,
	store_sales.ss_wholesale_cost,
	date_dim.d_week_seq,
	customer_demographics.cd_gender,
	date_dim.d_date_sk,
	date_dim.d_date,
	store_sales.ss_item_sk
FROM
	customer_demographics,
	date_dim,
	store_sales
WHERE
	(date_dim.d_year = 2000 OR date_dim.d_year = 2002)
	AND store_sales.ss_sold_date_sk = date_dim.d_date_sk
	AND store_sales.ss_cdemo_sk = customer_demographics.cd_demo_sk
	AND customer_demographics.cd_marital_status = 'S'
	AND customer_demographics.cd_gender = 'M'
	AND customer_demographics.cd_education_status = 'College'