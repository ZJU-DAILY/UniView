SELECT
	item.i_brand,
	item.i_units,
	item.i_size,
	inventory.inv_date_sk,
	inventory.inv_quantity_on_hand,
	item.i_product_name,
	inventory.inv_item_sk,
	item.i_item_desc,
	item.i_manufact_id,
	item.i_item_sk,
	item.i_brand_id,
	item.i_item_id,
	item.i_category_id,
	item.i_color,
	inventory.inv_warehouse_sk,
	item.i_wholesale_cost,
	item.i_class_id,
	item.i_category,
	item.i_manufact,
	item.i_class,
	item.i_current_price,
	item.i_manager_id
FROM
	item,
	inventory
WHERE
	(((item.i_manufact_id = 677) OR (item.i_manufact_id = 940) OR (item.i_manufact_id = 694) OR (item.i_manufact_id = 808)) OR ((item.i_manufact_id = 129) OR (item.i_manufact_id = 270) OR (item.i_manufact_id = 821) OR (item.i_manufact_id = 423)))
	AND item.i_item_sk = inventory.inv_item_sk
	AND (((inventory.inv_quantity_on_hand >= 100) AND (inventory.inv_quantity_on_hand <= 500)))