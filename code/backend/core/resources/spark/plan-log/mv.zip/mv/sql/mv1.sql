SELECT
	store.s_company_name,
	store.s_store_id,
	date_dim.d_month_seq,
	date_dim.d_dom,
	store_returns.sr_net_loss,
	store.s_gmt_offset,
	date_dim.d_year,
	store_returns.sr_return_quantity,
	store_returns.sr_item_sk,
	store_returns.sr_returned_date_sk,
	store.s_number_employees,
	date_dim.d_moy,
	date_dim.d_quarter_name,
	store.s_state,
	date_dim.d_qoy,
	store.s_store_sk,
	store.s_street_type,
	store.s_zip,
	store.s_city,
	store.s_company_id,
	store_returns.sr_reason_sk,
	date_dim.d_day_name,
	store.s_street_name,
	store.s_street_number,
	date_dim.d_dow,
	store.s_market_id,
	store.s_store_name,
	store.s_suite_number,
	store_returns.sr_customer_sk,
	store_returns.sr_ticket_number,
	date_dim.d_week_seq,
	store_returns.sr_store_sk,
	store.s_county,
	store_returns.sr_return_amt,
	date_dim.d_date_sk,
	date_dim.d_date,
	store_returns.sr_cdemo_sk
FROM
	store_returns,
	store,
	date_dim
WHERE
	store_returns.sr_returned_date_sk = date_dim.d_date_sk
	AND store_returns.sr_store_sk = store.s_store_sk
	AND date_dim.d_year = 2000
	AND store.s_state = 'TN'