SELECT
	item.i_brand,
	date_dim.d_month_seq,
	date_dim.d_dom,
	warehouse.w_county,
	item.i_manufact_id,
	date_dim.d_year,
	item.i_item_sk,
	warehouse.w_state,
	date_dim.d_date,
	inventory.inv_warehouse_sk,
	item.i_category_id,
	date_dim.d_moy,
	warehouse.w_warehouse_sq_ft,
	date_dim.d_qoy,
	date_dim.d_quarter_name,
	item.i_class_id,
	item.i_units,
	item.i_size,
	warehouse.w_warehouse_sk,
	inventory.inv_date_sk,
	inventory.inv_quantity_on_hand,
	date_dim.d_day_name,
	item.i_product_name,
	inventory.inv_item_sk,
	item.i_item_desc,
	date_dim.d_dow,
	warehouse.w_country,
	item.i_brand_id,
	warehouse.w_city,
	item.i_item_id,
	item.i_color,
	warehouse.w_warehouse_name,
	item.i_wholesale_cost,
	date_dim.d_week_seq,
	item.i_category,
	item.i_manufact,
	item.i_class,
	date_dim.d_date_sk,
	item.i_current_price,
	item.i_manager_id
FROM
	item,
	warehouse,
	inventory,
	date_dim
WHERE
	date_dim.d_year = 2001
	AND inventory.inv_date_sk = date_dim.d_date_sk
	AND (date_dim.d_moy = 1 OR date_dim.d_moy = 2)
	AND inventory.inv_item_sk = item.i_item_sk
	AND inventory.inv_warehouse_sk = warehouse.w_warehouse_sk